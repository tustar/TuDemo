package com.tustar.demo.common;

/**
 * Created by tustar on 16-3-11.
 */
public interface CommonDefine {

    String TEST_GIF = "/storage/emulated/0/img-9d0d09ably1fgslbs4vu3g20b205z7wm.gif";

}
