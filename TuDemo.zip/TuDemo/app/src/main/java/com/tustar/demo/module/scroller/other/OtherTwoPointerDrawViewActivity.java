package com.tustar.demo.module.scroller.other;

import android.os.Bundle;

import com.tustar.demo.R;
import com.tustar.demo.base.BaseActivity;

public class OtherTwoPointerDrawViewActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two_pointer_draw_view);
        setTitle(OtherTwoPointerDrawView.class.getSimpleName());
    }
}
