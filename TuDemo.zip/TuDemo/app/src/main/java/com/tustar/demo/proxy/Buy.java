package com.tustar.demo.proxy;

/**
 * Created by tustar on 18-1-26.
 */

public interface Buy {
    void buyHouse(long money);
}
