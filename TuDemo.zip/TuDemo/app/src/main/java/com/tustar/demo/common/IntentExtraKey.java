package com.tustar.demo.common;

/**
 * Created by tustar on 4/10/16.
 */
public interface IntentExtraKey {

    String TRANS_TYPE = "trans_type";
    String FLAG = "flag";
}
