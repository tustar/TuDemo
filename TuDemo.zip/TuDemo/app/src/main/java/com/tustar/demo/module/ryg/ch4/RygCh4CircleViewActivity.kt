package com.tustar.demo.module.ryg.ch4

import android.os.Bundle
import com.tustar.demo.R
import com.tustar.demo.base.BaseActivity

class RygCh4CircleViewActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ryg_ch4_circle_view)
        title = getString(R.string.ryg_ch4_circle_view)
    }
}
