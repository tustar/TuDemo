package com.tustar.demo.module.fm;

import android.os.Bundle;

import com.tustar.demo.R;

import androidx.appcompat.app.AppCompatActivity;

public class FmJavaRenameActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fm_rename);
    }
}
