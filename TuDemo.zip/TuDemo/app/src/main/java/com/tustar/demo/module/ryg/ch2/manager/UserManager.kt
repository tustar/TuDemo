package com.tustar.demo.module.ryg.ch2.manager

/**
 * Created by tustar on 17-6-15.
 */
object UserManager {
    var sUserId = 1
}
