package com.tustar.demo.module.ryg.ch15

import android.os.Bundle
import com.tustar.demo.R
import com.tustar.demo.module.ryg.base.BaseRygActivity

class RygCh15Activity : BaseRygActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = getString(R.string.ryg_ch15_title)
    }
}
