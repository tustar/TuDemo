package com.tustar.demo.common;

/**
 * Created by tustar on 16-3-11.
 */
public interface Preferences {
    String PREF_KEY_SIGNAL_CHECKED = "rf_signal_checked";
}
